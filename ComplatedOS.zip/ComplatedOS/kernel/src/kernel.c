
int _start(){
    return 123;
}