/*++

Copyright (c) 1998  Intel Corporation

Module Name:

    initplat.c

Abstract:




Revision History

--*/

#include "lib.h"

VOID
InitializeLibPlatform (
    IN EFI_HANDLE           ImageHandle EFI_UNUSED,
    IN EFI_SYSTEM_TABLE     *SystemTable EFI_UNUSED
    )
{
}

