/* SPDX-License-Identifier: GPL-2.0+ OR BSD-2-Clause */

VOID
InitializeLibPlatform (
    IN EFI_HANDLE           ImageHandle,
    IN EFI_SYSTEM_TABLE     *SystemTable
    );
