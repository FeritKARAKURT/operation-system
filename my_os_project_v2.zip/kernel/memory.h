#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

class MemoryManager {
public:
    MemoryManager();
    void* allocate(uint64_t size);
    void free(void* ptr);
private:
    uint64_t totalMemory;
};

#endif
