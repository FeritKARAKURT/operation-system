#include "memory.h"

MemoryManager::MemoryManager() {
    totalMemory = 1024 * 1024 * 128; // 128 MB bellek
}

void* MemoryManager::allocate(uint64_t size) {
    static uint64_t offset = 0x100000;
    void* ptr = (void*)offset;
    offset += size;
    return ptr;
}

void MemoryManager::free(void* ptr) {
    // Basit tahsis, serbest bırakma işlemi yapılmıyor.
}
