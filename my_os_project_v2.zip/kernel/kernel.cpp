#include "graphics.h"
#include "memory.h"
#include "keyboard.h"
#include "mouse.h"

extern "C" void kernel_main(Framebuffer* fb) {
    Graphics graphics(fb);
    MemoryManager memory;
    Keyboard keyboard;
    Mouse mouse;

    graphics.clearScreen(0x000000);
    graphics.drawRectangle(100, 100, 200, 150, 0x00FF00);

    while (1) {
        char key = keyboard.getKey();
        if (key) {
            graphics.drawCharacter(300, 300, key, 0xFFFFFF);
        }

        MousePosition pos = mouse.getPosition();
        graphics.drawPixel(pos.x, pos.y, 0xFF0000);
    }
}
