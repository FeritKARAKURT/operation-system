#include <efi.h>
#include <efilib.h>

typedef struct {
    void *BaseAddress;
    UINTN BufferSize;
    UINT32 Width;
    UINT32 Height;
    UINT32 PixelsPerScanLine;
} Framebuffer;

Framebuffer fb;

EFI_STATUS LoadKernel(EFI_PHYSICAL_ADDRESS KernelBaseAddress);
EFI_STATUS StartKernel(EFI_PHYSICAL_ADDRESS KernelBaseAddress);

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    InitializeLib(ImageHandle, SystemTable);
    EFI_STATUS Status;
    EFI_PHYSICAL_ADDRESS KernelBaseAddress = 0x100000;

    EFI_GRAPHICS_OUTPUT_PROTOCOL *GraphicsOutput;
    Status = uefi_call_wrapper(BS->LocateProtocol, 3, &GraphicsOutputProtocol, NULL, (VOID **)&GraphicsOutput);
    if (EFI_ERROR(Status)) {
        Print(L"Grafik protokolü bulunamadı!\n");
        return Status;
    }

    fb.BaseAddress = (void *)GraphicsOutput->Mode->FrameBufferBase;
    fb.BufferSize = GraphicsOutput->Mode->FrameBufferSize;
    fb.Width = GraphicsOutput->Mode->Info->HorizontalResolution;
    fb.Height = GraphicsOutput->Mode->Info->VerticalResolution;
    fb.PixelsPerScanLine = GraphicsOutput->Mode->Info->PixelsPerScanLine;

    Print(L"Framebuffer bilgileri alındı!\n");

    Status = LoadKernel(KernelBaseAddress);
    if (EFI_ERROR(Status)) {
        Print(L"Kernel yüklenemedi!\n");
        return Status;
    }

    void (*kernel_main)(Framebuffer*) = (void (*)(Framebuffer*))KernelBaseAddress;
    kernel_main(&fb);

    return EFI_SUCCESS;
}
