#include "keyboard.h"
#include <stdint.h>

#define KEYBOARD_PORT 0x60

Keyboard::Keyboard() { }

char Keyboard::getKey() {
    uint8_t scancode = *((volatile uint8_t*)KEYBOARD_PORT);
    return (char)scancode;
}
