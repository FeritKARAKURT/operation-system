#include "mouse.h"

Mouse::Mouse() { }

MousePosition Mouse::getPosition() {
    return { 400, 300 }; // Geçici statik değerler
}
