#ifndef MOUSE_H
#define MOUSE_H

struct MousePosition {
    int x;
    int y;
};

class Mouse {
public:
    Mouse();
    MousePosition getPosition();
};

#endif
