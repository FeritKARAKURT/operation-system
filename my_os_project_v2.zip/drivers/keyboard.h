#ifndef KEYBOARD_H
#define KEYBOARD_H

class Keyboard {
public:
    Keyboard();
    char getKey();
};

#endif
